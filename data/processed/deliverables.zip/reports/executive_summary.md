
# Uplift Policy — Executive Summary
_Date: 2025-09-17 22:40_

**Dataset:** Hillstrom test set  
**Margin:** 0.30 • **Contact cost:** 0.05

## 1) Best-N policy (by expected profit)
- Contact **15855** customers (**99.09%** of test)
- **Expected Profit ≈ 2,264.62**
- Avg incremental revenue/contact at best N ≈ **0.643**

## 2) Positive-margin-only policy
- Contact **4430** customers
- **Expected Profit ≈ 6,048.64** (Rev ≈ nan, Cost ≈ 221.50)
- _Note:_ This policy keeps only customers with **positive expected profit per contact**.

## 3) Uplift curve quality
- Approx. AUUC (decile gain area) ≈ **5,547.97**

## Artifacts
- `data/processed/policy_pack.xlsx`
- `data/processed/figs/policy_sensitivity_heatmap.png`
- `data/processed/reports/` (HTML dashboard)
- Contact lists:
  - `data/processed/final_contact_list_email.csv` (ranked)
  - `data/processed/final_contact_list_email_positive_only.csv` (pos-only)
  - `data/processed/contact_list_email_min.csv`
  - `data/processed/contact_list_email_positive_only_min.csv`
